<?php include('head.php') ?>
<section class="loginpage">
    <div class="container">
  <form action="#">
    <h2>Change Password </h2>

    
    <div class="input-field">
      <input type="password" required />
      <label>Enter New Password</label>
    </div>

        <div class="input-field">
      <input type="password" required />
      <label>Enter Confirm Password</label>
    </div>

  
    <button type="submit">Submit</button>
    <div class="Create-account">
      <p>Already have an account? <a href="login.php">Login</a></p>
    </div>
  </form>
</div>

</section>


<?php include('footer-bottom.php') ?>