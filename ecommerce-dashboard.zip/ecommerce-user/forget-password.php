<?php include('head.php') ?>
<section class="loginpage">
    <div class="container">
  <form action="#">
    <h2>Forget Password </h2>

    
    <div class="input-field">
      <input type="email" required />
      <label>Enter email</label>
    </div>


  
    <button type="submit">Submit</button>
    <div class="Create-account">
      <p>Already have an account? <a href="login.php">Login</a></p>
    </div>
  </form>
</div>

</section>

<?php include('footer-bottom.php') ?>